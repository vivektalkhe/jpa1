package com.cg.appl.services;

import java.util.List;

import com.cg.appl.dao.HrDaiImpl;
import com.cg.appl.dao.HrDao;
import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public class HrServicesImpl implements HrServices {

	private HrDao dao;
	
	public HrServicesImpl() throws HrException
	{
		dao=new HrDaiImpl();
	}
	
	@Override
	public Emp getEmpDetails(int empNo) throws HrException {
		
		return dao.getEmpDetailsSafe(empNo);
	}

	@Override
	public List<Emp> getEmpList() throws HrException {
		
		return dao.getEmpList();
	}

	/*@Override
	public Emp admitNewEmp(Emp emp) throws HrException {
		return dao.admitNewEmp(emp);
	}

	@Override
	public boolean updateName(int empNo, String newName) throws HrException {
		
		return dao.updateName(empNo, newName);
	}

	@Override
	public boolean updateEmp(Emp emp) throws HrException {
		// TODO Auto-generated method stub
		return dao.updateEmp(emp);
	}

	@Override
	public boolean deleteEmp(int empNo) throws HrException {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empNo);
	}*/

	@Override
	public List<Emp> getEmpsOnSal(float from, float to) throws HrException {
		// TODO Auto-generated method stub
		return dao.getEmpsOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpsForComm() throws HrException {
		// TODO Auto-generated method stub
		return dao.getEmpsForComm();
	}

	@Override
	public Dept getDeptDetails(int deptId) throws HrException {
		// TODO Auto-generated method stub
		return dao.getDeptDetails(deptId);
	}

}

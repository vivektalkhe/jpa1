package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public interface HrDao {
	
	Emp getEmpDetailsSafe(int empNo) throws HrException;
	
	List<Emp> getEmpList() throws HrException;
	
	/*Emp admitNewEmp(Emp emp) throws HrException;
	
	boolean updateName(int empNo,String newName) throws HrException;
	
	public boolean updateEmp(Emp emp) throws HrException;
	
	boolean deleteEmp(int empNo) throws HrException;*/
	
	List<Emp> getEmpsOnSal(float from,float to) throws HrException;
	
	List<Emp> getEmpsForComm() throws HrException;
	
	Dept getDeptDetails(int deptId) throws HrException;

}

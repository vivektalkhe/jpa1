package com.cg.appl.exceptions;

public class HrException extends Exception {

	public HrException() {
		// TODO Auto-generated constructor stub
	}

	public HrException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HrException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public HrException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public HrException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

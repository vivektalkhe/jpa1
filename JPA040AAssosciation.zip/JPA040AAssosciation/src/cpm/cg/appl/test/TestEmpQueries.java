package cpm.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.services.HrServices;
import com.cg.appl.services.HrServicesImpl;

public class TestEmpQueries {


	public static void main(String[] args) {
		try {
			HrServices services=new HrServicesImpl();
			//List<Emp> empList=services.getEmpsOnSal(2000, 4000);
			
			/*List<Emp> empList=services.getEmpList();
			for(Emp emp:empList)
			{
				
				System.out.println(empList);
			}
			*/
			
			
			Emp emp=services.getEmpDetails(7499);
			//Dept dept=services.getDeptDetails(emp.getDeptId());

			System.out.println(emp);
			//System.out.println(dept);
			
			System.out.println(emp.getDept().getDeptNm());
			
			
			System.out.println("======In Department=====");
			
			Dept dept=services.getDeptDetails(30);
			for(Emp emp1:dept.getEmps())	
			{
				System.out.println(emp1);	
			}
			System.out.println(dept);
			
			
			/*Emp emp=new Emp();
			emp.setEmpNm("Vide");
			emp.setEmpSal(50000f);
			emp=services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			/*
			List<Emp> empList=services.getEmpsForComm();
			
			for(Emp emp:empList)
			{
				System.out.println(emp);
			}*/
			
			
			
		} catch (HrException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
